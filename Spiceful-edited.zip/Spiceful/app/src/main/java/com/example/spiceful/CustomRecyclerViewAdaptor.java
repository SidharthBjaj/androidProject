package com.example.spiceful;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomRecyclerViewAdaptor extends RecyclerView.Adapter<CustomRecyclerViewAdaptor.CustomViewHolder> {

    private ArrayList<creditRecycle> creditRecycles;
    public CustomRecyclerViewAdaptor(ArrayList<creditRecycle> creditRecycles){
        this.creditRecycles = creditRecycles;
    }


    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_recycle_display,null);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {

        creditRecycle creditRecycle = creditRecycles.get(position);
        holder.name.setText(creditRecycle.getName());
//        holder.description.setText(creditRecycle.getDefination());
    }

    @Override
    public int getItemCount() {
        if (creditRecycles != null){
            return creditRecycles.size();
        }
        return 0;
    }
    class CustomViewHolder extends RecyclerView.ViewHolder{
        protected TextView name;
        protected TextView description;


        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            this.name = itemView.findViewById(R.id.name);
            this.description = itemView.findViewById(R.id.decription);
        }
    }
}