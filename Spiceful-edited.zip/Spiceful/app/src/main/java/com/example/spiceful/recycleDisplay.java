package com.example.spiceful;

public class recycleDisplay {

}