package com.example.spiceful;

public class creditRecycle {
    private  String name;
    private String defination;


    public creditRecycle(String name, String defination) {
        this.name = name;
        this.defination = defination;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDefination() {
        return defination;
    }

    public void setDefination(String defination) {
        this.defination = defination;
    }

    @Override
    public String toString() {
        return this.name;
    }
}

